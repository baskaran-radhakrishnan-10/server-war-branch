function fetchTestPlanEntries(){
	var entryCount=parseInt($('#build_test_plan_table_id_wrapper').find('select').val());
	var data={};
	data['maxEntries']=entryCount;
	data=JSON.stringify(data);
	console.log(data);
	ajaxHandler("POST", data, "application/json", getApplicationRootPath()+"build_test_plan/getData", 'json', null, fetchTestPlanEntriesSuccess,true);
}

function fetchTestPlanEntriesSuccess(serverData){
	console.log(serverData);
	
	
	
	$('#build_test_plan_table_id').find('#tbody_id').html(populateTestPlanEntries(serverData['BTP_ENTRIES']));
	$('#build_test_plan_table_id').DataTable({
		"responsive" : true,
		"processing": true,
		 "dom": 'Bfrtpl',
		 "buttons": ['excel','csv']
	});
	hideLoader();
}

function populateTestPlanEntries(entriesList){
	var sNo = 1;
	var htmlArray=new Array();
	for(var i=0;i<entriesList.length;i++){
		var html ="";
		var testPlanModelAttribute=entriesList[i];
		var gKey=testPlanModelAttribute['gKey'];
		var projectName=testPlanModelAttribute['projectName'];
		var btpPlan=testPlanModelAttribute['btpPlan'];
		var buildNo=testPlanModelAttribute['buildNo'];
		var btpStatus=testPlanModelAttribute['btpStatus'];
		var startDate=getDateValue(testPlanModelAttribute['startDate'],'dd/MM/yyyy',"/");
		var endDate=getDateValue(testPlanModelAttribute['endDate'],'dd/MM/yyyy',"/");
		var revisedEndDate=getDateValue(testPlanModelAttribute['revisedEndDate'],'dd/MM/yyyy',"/");
		buildTestPlanData[gKey]=testPlanModelAttribute;
		html += '<tr id="'+gKey+'">' ;
		html += '<td>'+sNo+'</td>' ;
		html += '<td>'+projectName+'</td>' ;
		html +=	'<td>'+btpPlan+'</td>' ;
		html += '<td>'+buildNo+'</td>' ;
		html += '<td>'+btpStatus+'</td>' ;
		html +=	'<td>'+startDate+'</td>' ;
		html += '<td>'+endDate+'</td>' ;
		html +=	'<td>'+revisedEndDate+'</td>' ;
		html += '<td id="testPlanEditRowId" onclick="buildTestPlanModalData('+gKey+')"><span><a href="#" class="glyphicon glyphicon-edit"></a></span><span>&nbsp;</span></td>' ;
		html += '</tr>' ;
		htmlArray.push(html);
		sNo++;
	}
	return htmlArray;
}

function buildTestPlanModalData(gKey){
	
	var currentSelectedObject=null;
	
	$('#selectedRowKeyInput').val(null != gKey ? gKey : "");
	
	currentSelectedObject = null != gKey ? buildTestPlanData[gKey] : null;
	
	selectedResourcesArray = null != currentSelectedObject ? constructResourceArray(currentSelectedObject) : [];
	
	fillSelectDropDown('projectId',projectArray, null != currentSelectedObject ? currentSelectedObject['projectName'] : "");
	
	fillSelectDropDown('phaseId',phaseArray, null != currentSelectedObject ? currentSelectedObject['phase'] : "");
	
	fillSelectDropDown('planId',planArray, null != currentSelectedObject ? currentSelectedObject['btpPlan'] : "");
	
	fillSelectDropDown('statusId',statusArray, null != currentSelectedObject ? currentSelectedObject['btpStatus'] : "");
	
	$('#cycleId').val( null != currentSelectedObject ? currentSelectedObject['cycle'] : "");
	
	$('#iteration_id').val( null != currentSelectedObject ? currentSelectedObject['sPrint'] : "");
	
	$('#buildNoId').val( null != currentSelectedObject ? currentSelectedObject['buildNo'] : "");
	
	$('#remarksId').val( null != currentSelectedObject ? currentSelectedObject['btpRemarks'] : "");
	
	$('#startDateId').val( null != currentSelectedObject ? getDateValue(currentSelectedObject['startDate'],'yyyy-MM-dd',"-") : "");
	
	$('#endDateId').val( null != currentSelectedObject ? getDateValue(currentSelectedObject['endDate'],'yyyy-MM-dd',"-") : "");
	
	$('#revisedEndDateId').val( null != currentSelectedObject ? getDateValue(currentSelectedObject['revisedEndDate'],'yyyy-MM-dd',"-") : "");
	
	constructResourceTable(selectedResourcesArray);
	
	$("#editBuildTestPlanTrigger").trigger( "click" );
	
	$('#buildTestPlanDiv').html($('#buildTestPlanForm'));
	
	$('#buildTestPlanDiv').find('#buildTestPlanForm').show();
	
	if(null == gKey){
		$('#itemDeatilsParentDivId').hide();
	}else{
		$('#itemDeatilsParentDivId').show();
	}
	
	if(null != gKey){
		fetchItemDetailsByBtpNo(gKey);
	}
	
}

function addOrUpdateBtp(){
	
	var btpObject={};
	
	var btpForm=$('#buildTestPlanDiv').find('form');
	
	var gKey=$('#selectedRowKeyInput').val();
	
	btpObject=gKey == "" ? {} : buildTestPlanData[gKey] ;
	btpObject['projectName']=btpForm.find('#projectId').val();
	btpObject['phase']=btpForm.find('#phaseId').val();
	btpObject['btpPlan']=btpForm.find('#planId').val();
	btpObject['btpStatus']=btpForm.find('#statusId').val();
	btpObject['cycle']=btpForm.find('#cycleId').val();
	btpObject['sPrint']=btpForm.find('#iteration_id').val();
	btpObject['buildNo']=btpForm.find('#buildNoId').val();
	btpObject['btpRemarks']=btpForm.find('#remarksId').val();
	btpObject['startDate']=btpForm.find('#startDateId').val();
	btpObject['endDate']=btpForm.find('#endDateId').val();
	btpObject['revisedEndDate']=btpForm.find('#revisedEndDateId').val();
	
	var objectKeys=Object.keys(btpObject);
	for(var index in objectKeys){
		var keyStr=objectKeys[index];
		if(keyStr.indexOf("resource") != -1){
			btpObject[keyStr]=null;
		}
	}
	
	btpForm.find('#resourceMgmtTableId').find('tr').each(function( index, element ) {
		if(null != element){
			var value=$(element).find('#resourceNameTDId')[0]['lastChild']['value'];
			btpObject['resource'+(index+1)]=value;
		}
	});
	
	btpObject['createdDate']=getDateValue(btpObject['createdDate'],'yyyy-MM-dd',"-");
	
	btpObject['updatesDate']=getDateValue(btpObject['updatesDate'],'yyyy-MM-dd',"-");
	
	
	if("" == gKey){
		ajaxHandler("POST", JSON.stringify(btpObject), "application/json", getApplicationRootPath()+"build_test_plan/addData", 'json', null, addBtpChangesSuccess,true);
	}else{
		ajaxHandler("POST", JSON.stringify(btpObject), "application/json", getApplicationRootPath()+"build_test_plan/updateData", 'json', null, updateBtpModifiedChangesSuccess,true);
	}
	
	console.log("%%%%%% GKey :"+gKey);
	
}

function updateBtpModifiedChangesSuccess(serverData){
	if('ERROR' != serverData['STATUS']){
		alert('Update Successfully!!!');
		window.location.href=getApplicationRootPath()+"build_test_plan/show";
	}else {
		alert('Update Operation Failed!!!');
	}
}

function addBtpChangesSuccess(serverData){
	if('ERROR' != serverData['STATUS']){
		alert('Added Successfully!!!');
		window.location.href=getApplicationRootPath()+"build_test_plan/show";
	}else {
		alert('Add Operation Failed!!!');
	}
}

function constructResourceArray(btpObject){
	var array=[];
	var objectKeys=Object.keys(btpObject);
	for(var index in objectKeys){
		var keyStr=objectKeys[index];
		if(keyStr.indexOf("resource") != -1){
			var value=btpObject[keyStr];
			if(null != value && value.length > 0){
				array.push(btpObject[keyStr]);
			}
		}
	}
	return array;
}

function addTableRow(thisObject){
	var html="";
	var resourceTrArray=$('#resourceMgmtTableId').find('tbody').find('tr');
	if(resourceTrArray.length <6){
		html += '<tr id="resourcetr_'+(resourceTrArray.length+1)+'">';
		html += '<td id="resourceNameCaptionId"><label class="control-label">Resource'+(resourceTrArray.length+1)+':*</label></td>';
		html += '<td id="resourceNameTDId" onclick="clickedResourceName(this)"><input id="resourceId" name="do_nbr" type="text" class="form-control form-control3" value=""></td>';
		html += '<td style="text-align: -webkit-center;">';
		html += '<a onclick="deleteTableRow(this)" href="#"><span class="fa fa-remove" data-toggle="tooltip" data-placement="auto top" title="" data-original-title="Remove Resource"></span></a>';
		html += '</td>';
		html += '</tr>';
		$('#resourceMgmtTableId').find('tbody').append(html);
	}else{
		alert("More than 6 resources not allowed per btp");
	}
}

function deleteTableRow(thisObject){
	var trElementId=$($(thisObject)[0]['parentNode'])[0]['parentNode']['id'];
	var resourceTrArray=$('#resourceMgmtTableId').find('tbody').find('tr');
	if(resourceTrArray.length > 1){
		var numId=parseInt(trElementId.replace('resourcetr_',''));
		var deletedRowId=numId;
		$('#resourceMgmtTableId').find('#'+trElementId).remove();
		while(numId <= 6){
			numId++;
			$('#resourceMgmtTableId').find('#resourcetr_'+numId).find('#resourceNameCaptionId').find('label').text('Resource'+(numId-1)+':');
			$('#resourceMgmtTableId').find('#resourcetr_'+numId).attr('id','resourcetr_'+(numId-1));
		}
	}else{
		alert("you can't delete primary resource for btp");
	}
}

function clickedResourceName(thisElement){
	
	var innerChildTagNmae=$(thisElement)[0]['firstChild']['tagName'];
	
	var resourceNameIndex=$(thisElement)[0]['parentElement']['id'].replace('resourcetr_','');
	
	if('INPUT' == innerChildTagNmae){
		$(thisElement).html(resourceArraySelectHtml);
		$(thisElement).find('select').val(selectedResourcesArray[resourceNameIndex-1]);
	}
	
}

