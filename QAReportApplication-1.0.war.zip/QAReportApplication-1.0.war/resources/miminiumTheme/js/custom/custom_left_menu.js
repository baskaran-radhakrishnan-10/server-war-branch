$(document).ready(function() {
	console.log("<----------------####@@@@Left Menu JS Loaded----------------####@@@@>");
})